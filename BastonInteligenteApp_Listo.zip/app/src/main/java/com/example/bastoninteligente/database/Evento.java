package com.example.bastoninteligente.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "evento")
public class Evento {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String descripcion;
    public long timestamp;

    public Evento(String descripcion, long timestamp) {
        this.descripcion = descripcion;
        this.timestamp = timestamp;
    }
}
