package com.example.bastoninteligente.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface HistorialDao {
    @Insert
    void insertarEvento(Evento evento);

    @Query("SELECT * FROM evento")
    List<Evento> obtenerEventos();
}
