package com.example.bastoninteligente.model;

public class SensorManager {
    public static void enviarVibracion() {
        // Aquí iría la lógica del sensor o vibración
        System.out.println("Vibración activada");
    }
}
