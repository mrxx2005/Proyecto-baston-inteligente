package com.example.bastoninteligente.controller;

import android.os.Bundle;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import com.example.bastoninteligente.R;
import com.example.bastoninteligente.database.AppDatabase;
import com.example.bastoninteligente.database.Evento;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("file:///android_asset/index.html");

        // Base de datos
        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "baston-db").allowMainThreadQueries().build();

        Evento evento = new Evento("Inicio de aplicación", System.currentTimeMillis());
        db.historialDao().insertarEvento(evento);
    }
}
